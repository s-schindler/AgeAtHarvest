/*
 * Author: Susanne Schindler
 * Date: 25.10.2013
 * Email: Susanne.Schindler2@web.de
 * Copyright: Susanne Schindler
 */

import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Writer;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.OutputStreamWriter;
import java.util.Date;
import java.util.Properties;
import java.util.ArrayList;
import java.text.DecimalFormat;

/**
 * main class to start a simulation
 */
public class StartSimulation {

    private static String inputFileName;
    private static String outputFileName_all = "Output/output_all";
    private static String outputFileName_legal = "Output/output_legal";
    private static String outputFileName_postHunt = "Output/output_postHunt";
    private static String outputFileName_postHunt_all = "Output/output_postHunt_all";
    private static String outputFileName_harvested = "Output/output_harvested";
    private static String outputFileName_yearsLegality = "Output/output_yearsLegality";
 
    private final String directory = "/home/sschindl/Forschung/Programme/AgeAtHarvest_FestaBianchet/allowNegativeHornGrowth/";

    /**
     * 
     * @param argv[] zero, one, two, or three parameters can be set
     * 1st param: filename of parameters
     * 2nd param: hunting pressure in percent (optional)
     * 3rd param: seed for random generator (optional)
     * 4th param: filename for output (optional)
     */
    public static void main (String argv[]) {
        Simulation sim;
        switch (argv.length) {
	case 1:
	    setInputFileName(argv[0]);
	    createOutputFiles();
	    Bighorn.setSurvivalRates(readSurvivalFromFile());
	    Bighorn.setInitialHornLength(readInitialHornLengthFromFile());
	    Bighorn.setInitialBaseCircumference(readInitialBaseCircumferenceFromFile());
	    Bighorn.setGrowthParams_horn(readMeanAnnuliFromFile(),readSDAnnuliFromFile());
	    Bighorn.setGrowthParams_base(readMeanBaseIncrementsFromFile(),readSDBaseIncrementsFromFile());
	    Bighorn.setLegalityParams(readLegalityLengthParamsFromFile(),readLegalityBaseParamsFromFile());
	    sim = new Simulation();
	    sim.setPopulationName(readPopulationFromFile());
	    sim.startSimulation();
	    break;
	case 2:
	    setInputFileName(argv[0]);
	    createOutputFiles();
	    Bighorn.setSurvivalRates(readSurvivalFromFile());
	    Bighorn.setInitialHornLength(readInitialHornLengthFromFile());
	    Bighorn.setInitialBaseCircumference(readInitialBaseCircumferenceFromFile());
	    Bighorn.setGrowthParams_horn(readMeanAnnuliFromFile(),readSDAnnuliFromFile());
	    Bighorn.setGrowthParams_base(readMeanBaseIncrementsFromFile(),readSDBaseIncrementsFromFile());
	    Bighorn.setLegalityParams(readLegalityLengthParamsFromFile(),readLegalityBaseParamsFromFile());
	    Population.setHuntingPressure(Double.parseDouble(argv[1]));
	    Simulation.setHuntingPressure(Double.parseDouble(argv[1]));
	    sim = new Simulation();
	    sim.setPopulationName(readPopulationFromFile());
	    sim.startSimulation();
	    break;
	case 3:
	    setInputFileName(argv[0]);
	    createOutputFiles();
	    Bighorn.setSurvivalRates(readSurvivalFromFile());
	    Bighorn.setInitialHornLength(readInitialHornLengthFromFile());
	    Bighorn.setInitialBaseCircumference(readInitialBaseCircumferenceFromFile());
	    Bighorn.setGrowthParams_horn(readMeanAnnuliFromFile(),readSDAnnuliFromFile());
	    Bighorn.setGrowthParams_base(readMeanBaseIncrementsFromFile(),readSDBaseIncrementsFromFile());
	    Bighorn.setLegalityParams(readLegalityLengthParamsFromFile(),readLegalityBaseParamsFromFile());
	    Population.setHuntingPressure(Double.parseDouble(argv[1]));
	    Simulation.setHuntingPressure(Double.parseDouble(argv[1]));
	    Simulation.setRandomSeed(Long.parseLong(argv[2]));
	    sim = new Simulation();
	    sim.setPopulationName(readPopulationFromFile());
	    sim.startSimulation();
	    break;
	case 4:
	    setInputFileName(argv[0]);
	    setOutputFileName(argv[3]);
	    createOutputFiles();
	    Bighorn.setSurvivalRates(readSurvivalFromFile());
	    Bighorn.setInitialHornLength(readInitialHornLengthFromFile());
	    Bighorn.setInitialBaseCircumference(readInitialBaseCircumferenceFromFile());
	    Bighorn.setGrowthParams_horn(readMeanAnnuliFromFile(),readSDAnnuliFromFile());
	    Bighorn.setGrowthParams_base(readMeanBaseIncrementsFromFile(),readSDBaseIncrementsFromFile());
	    Bighorn.setLegalityParams(readLegalityLengthParamsFromFile(),readLegalityBaseParamsFromFile());
	    Population.setHuntingPressure(Double.parseDouble(argv[1]));
	    Simulation.setHuntingPressure(Double.parseDouble(argv[1]));
	    Simulation.setRandomSeed(Long.parseLong(argv[2]));
	    sim = new Simulation();
	    sim.setPopulationName(readPopulationFromFile());
	    sim.startSimulation();
	    break;
	default:
	    System.out.println("StartSimulation: main: Invalid number of parameters.");
        }
    }

    private static void setInputFileName(String name){
	inputFileName = name;
    }

    private static void setOutputFileName(String name){
	outputFileName_all = name+"_all";
	outputFileName_legal = name+"_legal";
	outputFileName_postHunt = name+"_postHunt";
	outputFileName_postHunt_all = name+"_postHunt_all";
	outputFileName_harvested = name+"_harvested";
	outputFileName_yearsLegality = name+"_yearsLegality";
    }

    private static String readPopulationFromFile(){
	String popName = "Population not specified";	    
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    popName = prop.getProperty("population");
	}              
	catch (Exception e) {
	    System.out.println("StartSimulation:readPopulationFromFile: " + e.getMessage());
	}
	return popName;
    }


    private static double[] readSurvivalFromFile(){
	double[] survArray = new double[Bighorn.getNumberOfAges()];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    for (int i=Bighorn.getMinAge(); i<Bighorn.getMaxAge();i++){
		String propName = "SurvivalAtAge"+i;
		survArray[i-Bighorn.getMinAge()] = Double.parseDouble(prop.getProperty(propName));
	    }      
	}        
	catch (Exception e) {
	    System.out.println("StartSimulation:readSurvivalFromFile: " + e.getMessage());
	}
	return survArray;
    }

    private static double[] readInitialHornLengthFromFile(){
	double[] initialHornLengthStats  = new double[2];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    initialHornLengthStats[0] = Double.parseDouble(prop.getProperty("MeanLengthAtAge4"));
	    initialHornLengthStats[1] = Double.parseDouble(prop.getProperty("SDLengthAtAge4"));
	}      
	catch (Exception e) {
	    System.out.println("StartSimulation:readInitialHornLengthFromFile: " + e.getMessage());
	}
	return initialHornLengthStats;
    }

    private static double[] readMeanAnnuliFromFile(){
	double[] meanAnnuli  = new double[Bighorn.getNumberOfAges()];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    for (int i=Bighorn.getMinAge(); i<Bighorn.getMaxAge();i++){
		String propName = "MeanAnnulusAtAge"+i;
		meanAnnuli[i-Bighorn.getMinAge()] = Double.parseDouble(prop.getProperty(propName));
	    }      
	}        
	catch (Exception e) {
	    System.out.println("StartSimulation:readMeanAnnuliFromFile: " + e.getMessage());
	}
	return meanAnnuli;
    }

    private static double[] readSDAnnuliFromFile(){
	double[] SDAnnuli  = new double[Bighorn.getNumberOfAges()];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    for (int i=Bighorn.getMinAge(); i<Bighorn.getMaxAge();i++){
		String propName = "SDAnnulusAtAge"+i;
		SDAnnuli[i-Bighorn.getMinAge()] = Double.parseDouble(prop.getProperty(propName));
	    }      
	}        
	catch (Exception e) {
	    System.out.println("StartSimulation:readSDAnnuliFromFile: " + e.getMessage());
	}
	return SDAnnuli;
    }

    private static double[] readInitialBaseCircumferenceFromFile(){
	double[] initialBaseStats  = new double[2];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    initialBaseStats[0] = Double.parseDouble(prop.getProperty("MeanCircumferenceAtAge4"));
	    initialBaseStats[1] = Double.parseDouble(prop.getProperty("SDCircumferenceAtAge4"));
	}      
	catch (Exception e) {
	    System.out.println("StartSimulation:readInitialBaseCircumferenceFromFile: " + e.getMessage());
	}
	return initialBaseStats;
    }

    private static double[] readMeanBaseIncrementsFromFile(){
	double[] meanBaseIncr  = new double[Bighorn.getNumberOfAges()];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    for (int i=Bighorn.getMinAge(); i<Bighorn.getMaxAge();i++){
		String propName = "MeanBaseIncrementAtAge"+i;
		meanBaseIncr[i-Bighorn.getMinAge()] = Double.parseDouble(prop.getProperty(propName));
	    }      
	}        
	catch (Exception e) {
	    System.out.println("StartSimulation:readMeanBaseIncrementsFromFile: " + e.getMessage());
	}
	return meanBaseIncr;
    }

    private static double[] readSDBaseIncrementsFromFile(){
	double[] SDBaseIncr  = new double[Bighorn.getNumberOfAges()];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    for (int i=Bighorn.getMinAge(); i<Bighorn.getMaxAge();i++){
		String propName = "SDBaseIncrementAtAge"+i;
		SDBaseIncr[i-Bighorn.getMinAge()] = Double.parseDouble(prop.getProperty(propName));
	    }      
	}        
	catch (Exception e) {
	    System.out.println("StartSimulation:readSDBaseIncrementsFromFile: " + e.getMessage());
	}
	return SDBaseIncr;
    }


    private static double[] readLegalityLengthParamsFromFile(){
	double[] paramsLength  = new double[2];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    String propName = "LegalInterceptLength";
	    paramsLength[0] = Double.parseDouble(prop.getProperty(propName));
	    propName = "LegalSlopeLength";
	    paramsLength[1] = Double.parseDouble(prop.getProperty(propName));
	    }      
	catch (Exception e) {
	    System.out.println("StartSimulation:readLegalityLengthParamsFromFile: " + e.getMessage());
	}
	return paramsLength;
    }

    private static double[] readLegalityBaseParamsFromFile(){
	double[] paramsBase  = new double[2];
	try {
	    Properties prop = new Properties();
	    prop.load(new FileInputStream(inputFileName));
	    String propName = "LegalInterceptBase";
	    paramsBase[0] = Double.parseDouble(prop.getProperty(propName));
	    propName = "LegalSlopeBase";
	    paramsBase[1] = Double.parseDouble(prop.getProperty(propName));
	    }      
	catch (Exception e) {
	    System.out.println("StartSimulation:readLegalityBaseParamsFromFile: " + e.getMessage());
	}
	return paramsBase;
    }

    static void printToScreen(int arraySize, int[] array){
	/* print on screen */
	System.out.println("\nAge:");
	for (int i=0; i<arraySize; i++)
	    System.out.print((i+Bighorn.getMinAge())+"\t");
	System.out.println("\nCount:");
	printToStream(arraySize,array,new BufferedWriter((new OutputStreamWriter(System.out))));
    }


    static void printToScreen(int arraySize, double[] array){
	/* print on screen */
	System.out.println("\nAge:");
	for (int i=0; i<arraySize; i++)
	    System.out.print((i+Bighorn.getMinAge())+"\t");
	System.out.println("\nStats:");
	printToStream(arraySize,array,new BufferedWriter((new OutputStreamWriter(System.out))));
    }

    static void printStatsToScreen(int arraySizes,int[] array1,double[] array2, double[] array3,double[] array4, double[] array5){
	/* print on screen */
	System.out.println("\nAge:");
	for (int i=0; i<arraySizes; i++)
	    System.out.print((i+Bighorn.getMinAge())+"\t");
	System.out.println("\nCount:");
	printToStream(arraySizes,array1,new BufferedWriter((new OutputStreamWriter(System.out))));
	System.out.println("Mean horn length:");
	printToStream(arraySizes,array2,new BufferedWriter((new OutputStreamWriter(System.out))));
	System.out.println("SD horn length:");
	printToStream(arraySizes,array3,new BufferedWriter((new OutputStreamWriter(System.out))));
	System.out.println("Mean base circumference:");
	printToStream(arraySizes,array4,new BufferedWriter((new OutputStreamWriter(System.out))));
	System.out.println("SD base circumference:");
	printToStream(arraySizes,array5,new BufferedWriter((new OutputStreamWriter(System.out))));
    }

    private static void createOutputFiles(){
	try {
	    File file1 = new File(outputFileName_all);
	    File file2 = new File(outputFileName_legal);
	    File file3 = new File(outputFileName_postHunt);
	    File file4 = new File(outputFileName_postHunt_all);
	    File file5 = new File(outputFileName_harvested);
	    File file6 = new File(outputFileName_yearsLegality);
	    if(file1.exists())
		file1.delete(); // delete file to write to empty file
	    if(file2.exists())
		file2.delete();
	    if(file3.exists())
		file3.delete();
	    if(file4.exists())
		file4.delete();
	    if(file5.exists())
		file5.delete();
	    if(file6.exists())
		file6.delete();
	    /* (re)create it  */
	    file1.createNewFile();
	    file2.createNewFile();
	    file3.createNewFile();
	    file4.createNewFile();
	    file5.createNewFile();
	    file6.createNewFile();
	}catch (Exception e) {
	    System.out.println("StartSimulation:createOutputFiles:"+e.getMessage());
	}
    }
 
    static void printToFile(int arraySize, int[] array1,double[] array2, double[] array3, double[] array4){
	/* output to file */
	try {
	    int arraySize2 = arraySize + 2*2*arraySize;
	    double[] doubleArray = new double[arraySize2];
	    System.arraycopy(array2,0,doubleArray,0,2*arraySize);
	    System.arraycopy(array3,0,doubleArray,2*arraySize,2*arraySize);
	    System.arraycopy(array4,0,doubleArray,4*arraySize,arraySize);

	    printToStream(arraySize,array1,arraySize2,doubleArray,new BufferedWriter(new FileWriter(new File(outputFileName_all),Boolean.TRUE)));
	} catch (Exception e) {
	    System.out.println("StartSimulation:printToFile:"+e.getMessage());
	}
    }
 
 
    static void printToFile_legal(int arraySize, int[] array1,double[] array2, double[] array3, double[] array4){
	/* output to file */
	try {
	    int arraySize2 = arraySize + 2*2*arraySize;
	    double[] doubleArray = new double[arraySize2];
	    System.arraycopy(array2,0,doubleArray,0,2*arraySize);
	    System.arraycopy(array3,0,doubleArray,2*arraySize,2*arraySize);
	    System.arraycopy(array4,0,doubleArray,4*arraySize,arraySize);

	    printToStream(arraySize,array1,arraySize2,doubleArray,new BufferedWriter(new FileWriter(new File(outputFileName_legal),Boolean.TRUE)));
	} catch (Exception e) {
	    System.out.println("StartSimulation:printToFile_legal:"+e.getMessage());
	}
    }
 
    static void printToFile_postHunt(int arraySize, int[] array1,double[] array2, double[] array3, double[] array4){
	/* output to file */
	try {
	    int arraySize2 = arraySize + 2*2*arraySize;
	    double[] doubleArray = new double[arraySize2];
	    System.arraycopy(array2,0,doubleArray,0,2*arraySize);
	    System.arraycopy(array3,0,doubleArray,2*arraySize,2*arraySize);
	    System.arraycopy(array4,0,doubleArray,4*arraySize,arraySize);

	    printToStream(arraySize,array1,arraySize2,doubleArray,new BufferedWriter(new FileWriter(new File(outputFileName_postHunt),Boolean.TRUE)));
	} catch (Exception e) {
	    System.out.println("StartSimulation:printToFile_postHunt:"+e.getMessage());
	}
    }

    static void printToFile_postHunt_all(int arraySize, int[] array1,double[] array2, double[] array3, double[] array4){
	/* output to file */
	try {
	    int arraySize2 = arraySize + 2*2*arraySize;
	    double[] doubleArray = new double[arraySize2];
	    System.arraycopy(array2,0,doubleArray,0,2*arraySize);
	    System.arraycopy(array3,0,doubleArray,2*arraySize,2*arraySize);
	    System.arraycopy(array4,0,doubleArray,4*arraySize,arraySize);

	    printToStream(arraySize,array1,arraySize2,doubleArray,new BufferedWriter(new FileWriter(new File(outputFileName_postHunt_all),Boolean.TRUE)));
	} catch (Exception e) {
	    System.out.println("StartSimulation:printToFile_postHunt:"+e.getMessage());
	}
    }

    static void printToFile_hunted(int arraySize, int[] array1,double[] array2, double[] array3, double[] array4){
	/* output to file */
	try {
	    int arraySize2 = arraySize + 2*2*arraySize;
	    double[] doubleArray = new double[arraySize2];
	    System.arraycopy(array2,0,doubleArray,0,2*arraySize);
	    System.arraycopy(array3,0,doubleArray,2*arraySize,2*arraySize);
	    System.arraycopy(array4,0,doubleArray,4*arraySize,arraySize);

	    printToStream(arraySize,array1,arraySize2,doubleArray,new BufferedWriter(new FileWriter(new File(outputFileName_harvested),Boolean.TRUE)));
	} catch (Exception e) {
	    System.out.println("StartSimulation:printToFile_hunted:"+e.getMessage());
	}
    }
 
    static void printToFile_yearsOfLegality(int arraySize, int[] array1){
	/* output to file */
	try {
	    printToStream(arraySize,array1,new BufferedWriter(new FileWriter(new File(outputFileName_yearsLegality),Boolean.TRUE)));
	} catch (Exception e) {
	    System.out.println("StartSimulation:printToFile_yearsOfLegality:"+e.getMessage());
	}
    }



    private static void printToStream(int arraySize1, int[] array1, int arraySize2, double[] array2, Writer bs){
	try{
	    for (int i=0; i<arraySize1; i++)
		bs.write(array1[i]+"\t");

	    DecimalFormat df = new DecimalFormat();
	    df.setMaximumFractionDigits(4);	
	    for (int i=0; i<arraySize2; i++)
		bs.write(df.format(array2[i])+"\t");

	    bs.write("\n");
	    bs.flush();
	}catch (Exception e) {
	    System.out.println("StartSimulation:printToStream:"+e.getMessage());
	}
    }

    private static void printToStream(int arraySize, int[] array,Writer bs){
	try{
	    for (int i=0; i<arraySize; i++)
		bs.write(array[i]+"\t");
	    bs.write("\n");
	    bs.flush();
	}catch (Exception e) {
	    System.out.println("StartSimulation:printToStream:"+e.getMessage());
	}
    }

    private static void printToStream(int arraySize, double[] array,Writer bs){
	try{
	    DecimalFormat df = new DecimalFormat();
	    df.setMaximumFractionDigits(4);	
	    for (int i=0; i<arraySize; i++)
		bs.write(df.format(array[i])+"\t");
	    bs.write("\n");
	    bs.flush();
	}catch (Exception e) {
	    System.out.println("StartSimulation:printToStream:"+e.getMessage());
	}
    }

}



