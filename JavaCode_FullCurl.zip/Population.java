/*
 * Author: Susanne Schindler
 * Date: 25.10.2013
 * Email: Susanne.Schindler2@web.de
 * Copyright: Susanne Schindler
 */


import java.util.LinkedList;
import java.util.Iterator;
import java.util.Random;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;


/**
 * 
 */
public class Population {

    private LinkedList<Bighorn> rams;
    private Random randomGenerator;

    private static double fractionHunted = 0;

    /**
     * constructor
     * 
     */
    public Population (long seed) {
	initiateLists();
	initiateRandomGenerator(seed);
    }

    private void initiateLists(){
	rams = new LinkedList<Bighorn>();
   }

    private void initiateRandomGenerator(Long seed){
	randomGenerator = new Random(seed);
    }

    static void setHuntingPressure(double pressure){
	fractionHunted = pressure;
    }

    public void addCohort(int cohortSize){
	for (int i=1; i<=cohortSize; i++)
	    rams.add(new Bighorn());
    }

    public void updateLegalRams(){
	/* for every non legal pop-member check legality and copy either to legal or notLegal pop*/
	for(Bighorn ram : rams)
	    ram.updateLegality();
    }


    public LinkedList<Bighorn> applyNaturalSelection(){
	double rand;

	/* if population is unhunted, we need the list of legal ram that died */
	/* naturally to be able to calculate life-expectancy of legal rams under no-hunting */
	LinkedList<Bighorn> deadLegalRams = new LinkedList<Bighorn>();

	/* depending on natural mortality some rams die */
	/* iterate through list of rams */
	for(Iterator<Bighorn> it =rams.iterator(); it.hasNext();){
	    /* get random number */
	    rand = randomGenerator.nextDouble();
	    /* if rand one is smaller than surv(age) prob then ram survives */
	    Bighorn ram = it.next();
	    if(rand >= Bighorn.getSurvivalAtAge(ram.getAge())){
		if(ram.getIsLegal())
		    deadLegalRams.add(ram);
		it.remove();
	    }
	}
	return deadLegalRams;
    }

    public void growHorns(){
	for(Bighorn ram : rams)
	    ram.growHorn();
    }

    public LinkedList<Bighorn> getAndRemoveHuntedRams(){
	/* create list of potentially hunted rams */
	LinkedList<Bighorn> huntedRams = new LinkedList<Bighorn>();
	/* get legal rams */
	LinkedList<Bighorn> legalRams = getLegalRams();
	/* go through list of legal rams and apply mortality through hunting*/
	for (Iterator<Bighorn> it =legalRams.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    if(randomGenerator.nextDouble()*100 <= getHuntingPressure()){
		huntedRams.add(ram);
		rams.remove(ram); /* remove ram from population */
	    }
	}
	/* return list of shot rams */
	return huntedRams;
    }

    public void ageing(){
	for(Bighorn ram : rams)
	    ram.ageing();
    }

    static double getHuntingPressure(){
	return fractionHunted;
    }

    public int getSize(){
	return rams.size();
    }

    public LinkedList<Bighorn> getRams(){return rams;}

    private LinkedList<Bighorn> getLegalRams(){
	LinkedList<Bighorn> legalRams = new LinkedList<Bighorn>();
	for(Bighorn ram : rams){
	    if(ram.getIsLegal())
		legalRams.add(ram);
	}
	return legalRams;
    }

    public void outputStats(LinkedList<Bighorn> killedRams){
	int[] ageDistr = getAgeDistribution(rams);
	double[] hornLength = getAgeSpecificMeanAndSDHornLength(ageDistr,rams);
	double[] hornBase = getAgeSpecificMeanAndSDBaseCircumference(ageDistr,rams);
	double[] corr = getAgeSpecificCorrelationLengthCircumference(ageDistr,rams);
	StartSimulation.printToFile(Bighorn.getNumberOfAges(),ageDistr,hornLength,hornBase,corr);

	LinkedList<Bighorn> legalRams= getLegalRams();
	int[] ageDistr_legal = getAgeDistribution(legalRams);
	double[] hornLength_legal = getAgeSpecificMeanAndSDHornLength(ageDistr_legal,legalRams);
	double[] hornBase_legal = getAgeSpecificMeanAndSDBaseCircumference(ageDistr_legal,legalRams);
	double[] corr_legal = getAgeSpecificCorrelationLengthCircumference(ageDistr_legal,legalRams);
	StartSimulation.printToFile_legal(Bighorn.getNumberOfAges(),ageDistr_legal,hornLength_legal,hornBase_legal,corr_legal);

	// define arrays outside of if-else
	int[] ageDistr_hunted;
	double[] hornLength_hunted,hornBase_hunted, corr_hunted;

	if(fractionHunted < 0.01){
	    LinkedList<Bighorn> emptyList = new LinkedList<Bighorn>();
	    ageDistr_hunted = getAgeDistribution(emptyList);
	    hornLength_hunted = getAgeSpecificMeanAndSDHornLength(ageDistr_hunted,emptyList);
	    hornBase_hunted = getAgeSpecificMeanAndSDBaseCircumference(ageDistr_hunted,emptyList);
	    corr_hunted = getAgeSpecificCorrelationLengthCircumference(ageDistr_hunted,emptyList);
	}
	else{
	    ageDistr_hunted = getAgeDistribution(killedRams);
	    hornLength_hunted = getAgeSpecificMeanAndSDHornLength(ageDistr_hunted,killedRams);
	    hornBase_hunted = getAgeSpecificMeanAndSDBaseCircumference(ageDistr_hunted,killedRams);
	    corr_hunted = getAgeSpecificCorrelationLengthCircumference(ageDistr_hunted,killedRams);
	}
	StartSimulation.printToFile_hunted(Bighorn.getNumberOfAges(),ageDistr_hunted,hornLength_hunted,hornBase_hunted,corr_hunted);

	int[] yearsOfLegalityDistr = getYearsOfLegalityDistr(killedRams);
	StartSimulation.printToFile_yearsOfLegality(Bighorn.getNumberOfAges(),yearsOfLegalityDistr);
    }

    public void outputPostHuntStats(){
	int[] ageDistr = getAgeDistribution(rams);
	double[] hornLength = getAgeSpecificMeanAndSDHornLength(ageDistr,rams);
	double[] hornBase = getAgeSpecificMeanAndSDBaseCircumference(ageDistr,rams);
	double[] corr = getAgeSpecificCorrelationLengthCircumference(ageDistr,rams);
	StartSimulation.printToFile_postHunt_all(Bighorn.getNumberOfAges(),ageDistr,hornLength,hornBase,corr);

	LinkedList<Bighorn> legalRams= getLegalRams();
	int[] ageDistr_legal = getAgeDistribution(legalRams);
	double[] hornLength_legal = getAgeSpecificMeanAndSDHornLength(ageDistr_legal,legalRams);
	double[] hornBase_legal = getAgeSpecificMeanAndSDBaseCircumference(ageDistr_legal,legalRams);
	double[] corr_legal = getAgeSpecificCorrelationLengthCircumference(ageDistr_legal,legalRams);
	StartSimulation.printToFile_postHunt(Bighorn.getNumberOfAges(),ageDistr_legal,hornLength_legal,hornBase_legal,corr_legal);
    }


    private static int[] getAgeDistribution(LinkedList<Bighorn>list){
	int arraySize = Bighorn.getNumberOfAges();
	int[] ageArray = new int[arraySize];
	/* get histogramm */
	for (Iterator<Bighorn> it=list.iterator();it.hasNext();){
	    ageArray[it.next().getAge()-Bighorn.getMinAge()]++;
	}
	return ageArray;
    }

    private static int[] getYearsOfLegalityDistr(LinkedList<Bighorn>list){
	int arraySize = Bighorn.getNumberOfAges();
	int[] ageArray = new int[arraySize];
	/* get histogramm */
	for (Iterator<Bighorn> it=list.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    ageArray[ram.getAge()-ram.getAgeAtLegality()]++;
	}
	return ageArray;
    }

    private static double[] getAgeSpecificMeanHornLength(int[] ageDistr,LinkedList<Bighorn>list){
	int arraySize = Bighorn.getNumberOfAges();
	double[] sumHornLengths = new double[arraySize];
	double[] meanHornLength = new double[arraySize];

	for(Iterator<Bighorn> it=list.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    int ageIndex = ram.getAge()-Bighorn.getMinAge();
	    sumHornLengths[ageIndex] = sumHornLengths[ageIndex]+ram.getHornLength();
	}
	for(int a=0;a<arraySize;a++)
	    if(ageDistr[a]>0)
		meanHornLength[a] = sumHornLengths[a]/ageDistr[a];
	return meanHornLength;
    }

    private static double[] getAgeSpecificSDHornLength(double[] meanLengths,int[] ageDistr,LinkedList<Bighorn>list){
	int arraySize = Bighorn.getNumberOfAges();
	double[] devHornLengths = new double[arraySize];
	double[] SDHornLength = new double[arraySize];
	for(Iterator<Bighorn> it=list.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    int ageIndex = ram.getAge()-Bighorn.getMinAge();
	    devHornLengths[ageIndex] = devHornLengths[ageIndex]+Math.pow(ram.getHornLength()-meanLengths[ageIndex],2);
	}
	for(int a=0;a<arraySize;a++)
	    if(ageDistr[a]>1)
		SDHornLength[a] = Math.sqrt(devHornLengths[a]/(ageDistr[a]-1));
	return SDHornLength;
    }

    private static double[] getAgeSpecificMeanAndSDHornLength(int[] ageDistr,LinkedList<Bighorn>list){
	double[] meanArray = getAgeSpecificMeanHornLength(ageDistr,list);
	double[] SDarray = getAgeSpecificSDHornLength(meanArray,ageDistr,list);
	double[] combinedArray = new double[2*Bighorn.getNumberOfAges()];
	System.arraycopy(meanArray,0,combinedArray,0,Bighorn.getNumberOfAges());
	System.arraycopy(SDarray,0,combinedArray,Bighorn.getNumberOfAges(),Bighorn.getNumberOfAges());
	return combinedArray;
    }

    private static double[] getAgeSpecificMeanBaseCircumference(int[] ageDistr,LinkedList<Bighorn>list){
	int arraySize = Bighorn.getNumberOfAges();
	double[] sumBaseCircumferences = new double[arraySize];
	double[] meanBaseCircumference = new double[arraySize];

	for(Iterator<Bighorn> it=list.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    int ageIndex = ram.getAge()-Bighorn.getMinAge();
	    sumBaseCircumferences[ageIndex] = sumBaseCircumferences[ageIndex]+ram.getBaseCircumference();
	}
	for(int a=0;a<arraySize;a++)
	    if(ageDistr[a]>0)
		meanBaseCircumference[a] = sumBaseCircumferences[a]/ageDistr[a];
	return meanBaseCircumference;
    }

    private static double[] getAgeSpecificSDBaseCircumference(double[] meanCircumferences,int[] ageDistr,LinkedList<Bighorn>list){
	int arraySize = Bighorn.getNumberOfAges();
	double[] devCircumference = new double[arraySize];
	double[] SDCircumference = new double[arraySize];
	for(Iterator<Bighorn> it=list.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    int ageIndex = ram.getAge()-Bighorn.getMinAge();
	    devCircumference[ageIndex] = devCircumference[ageIndex]+Math.pow(ram.getBaseCircumference()-meanCircumferences[ageIndex],2);
	}
	for(int a=0;a<arraySize;a++)
	    if(ageDistr[a]>1)
		SDCircumference[a] = Math.sqrt(devCircumference[a]/(ageDistr[a]-1));
	return SDCircumference;
    }

    private static double[] getAgeSpecificMeanAndSDBaseCircumference(int[] ageDistr,LinkedList<Bighorn>list){
	double[] meanArray = getAgeSpecificMeanBaseCircumference(ageDistr,list);
	double[] SDarray = getAgeSpecificSDBaseCircumference(meanArray,ageDistr,list);
	double[] combinedArray = new double[2*Bighorn.getNumberOfAges()];
	System.arraycopy(meanArray,0,combinedArray,0,Bighorn.getNumberOfAges());
	System.arraycopy(SDarray,0,combinedArray,Bighorn.getNumberOfAges(),Bighorn.getNumberOfAges());
	return combinedArray;
    }

    private static double[] getAgeSpecificCorrelationLengthCircumference(int[] ageDistr,LinkedList<Bighorn>list){
	double[] meanSDLength = getAgeSpecificMeanAndSDHornLength(ageDistr,list);
	double[] meanSDBase = getAgeSpecificMeanAndSDBaseCircumference(ageDistr,list);
	int arraySize = Bighorn.getNumberOfAges();
	double[] corr = new double[arraySize];
	for(Iterator<Bighorn> it=list.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    int ageIndex = ram.getAge()-Bighorn.getMinAge();
	    corr[ageIndex] = corr[ageIndex]+(ram.getHornLength()-meanSDLength[ageIndex])*(ram.getBaseCircumference()-meanSDBase[ageIndex]);
	}
	for(int a=0;a<arraySize;a++){
	    double product = meanSDLength[a+arraySize]*meanSDBase[a+arraySize]*ageDistr[a];
	    if(product > 0)
		corr[a] = corr[a]/product;
	}
	return corr;
    }


    public void printPopulation(){
	for(Iterator<Bighorn> it = rams.iterator(); it.hasNext();){
	    Bighorn ram = it.next();
	    System.out.println(ram+", hL="+ram.getHornLength()+", hC="+ram.getBaseCircumference());
	}
    }

    public void printLegalPopulation(){
	LinkedList<Bighorn> legalRams = getLegalRams();
	for(Iterator<Bighorn> it = legalRams.iterator(); it.hasNext();){
	    Bighorn ram = it.next();
	    System.out.println(ram+", hL="+ram.getHornLength()+", hC="+ram.getBaseCircumference()+", aL="+ram.getAgeAtLegality());
	}
    }
}



