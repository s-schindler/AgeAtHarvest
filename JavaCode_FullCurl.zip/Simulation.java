/*
 * Author: Susanne Schindler
 * Date: 25.10.2013
 * Email: Susanne.Schindler2@web.de
 * Copyright: Susanne Schindler
 */



import java.util.LinkedList;
import java.util.Random;
import java.util.Iterator;

/**
 * 
 */
public class Simulation {
    private Population population;
    private LinkedList<Bighorn> harvestedPopulation; // collects the hunted individuals of the current hunting season (not all ever harvested rams)
    private LinkedList<Bighorn> deadLegalRams; // collects the legal rams that died through natural causes

    private int initialCohortSize;
    private int numberTimeSteps;
    private double cohortDeviation;

    private Random randomGenerator;

    private static Long randomSeed = new Long(2202);
    private static double fractionHunted = 0;
    private static final String defaultPopName = "Arbitrary Population";

    private String popName = defaultPopName;


    /**
     * constructor
     * 
     */
    public Simulation() {
	initiateRandomGenerator();
	initiatePopulation();
	initiateLists();
	setParameters();
    }

    private void initiatePopulation(){
	population = new Population(randomGenerator.nextLong());
    }

    private void initiateLists(){
	harvestedPopulation = new LinkedList<Bighorn>();
	deadLegalRams = new LinkedList<Bighorn>();
    }


    public void setPopulationName(String name){
	popName = name;
    }

    static void setHuntingPressure(double pressure){
	fractionHunted = pressure;
    }

    private void setParameters(){
	initialCohortSize = 100;
	cohortDeviation = initialCohortSize/10;
	numberTimeSteps = 100;
    }

    static void setRandomSeed(long seed){
	randomSeed = seed;
   }

    private void initiateRandomGenerator(){
	randomGenerator = new Random(randomSeed);
	Bighorn.initateRandomGenerator(randomGenerator.nextLong());
    }

    public void startSimulation(){
	System.out.println(" Simulation for "+ popName+" starts.\n Iterating...");
	// no hunting for the first years
	for(int i=1; i<Bighorn.getNumberOfAges(); i++){
 	    System.out.print("\r "+i);
	    population.addCohort(getRandomCohortSize());
  	    population.updateLegalRams();
	    if(fractionHunted < 0.01)
		population.outputStats(deadLegalRams);
	    else
		population.outputStats(harvestedPopulation);
	    population.outputPostHuntStats();
	    deadLegalRams.clear();
	    deadLegalRams = population.applyNaturalSelection();
	    population.growHorns();
	    population.ageing();
	}
	// now rams are potentially present in all age classes 
	// hunting starts
	for(int i=Bighorn.getNumberOfAges(); i<=numberTimeSteps; i++){
	    System.out.print("\r "+i);
	    population.addCohort(getRandomCohortSize());
  	    population.updateLegalRams();
	    if(fractionHunted < 0.01)
		population.outputStats(deadLegalRams);
	    else
		population.outputStats(harvestedPopulation);
	    updateHarvestedPopulation();
	    population.outputPostHuntStats();
	    deadLegalRams.clear();
	    deadLegalRams = population.applyNaturalSelection();
	    population.growHorns();
	    population.ageing();
	}
	System.out.println("\n Simulation ends.");
   }

    private int updateHarvestedPopulation(){
	// empty list
	harvestedPopulation.clear();
	// add newly hunted
	harvestedPopulation.addAll(population.getAndRemoveHuntedRams());
	return harvestedPopulation.size();
    }

    private int getRandomCohortSize(){
	/* draw number from distribution with mean <initialCohortSize> and SD <cohortDeviation>*/
	return Math.max(0,(int)Math.round(randomGenerator.nextGaussian()*cohortDeviation+initialCohortSize));
    }

    private void printHarvestedPopulation(){
	System.out.println("number hunted = "+harvestedPopulation.size());
	for(Iterator<Bighorn> it=harvestedPopulation.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    System.out.println(ram+" aged = "+(ram.getAge())+", hL= "+(ram.getHornLength())+", hB= "+(ram.getBaseCircumference()));
	}
    }

    private void printOldPopulation(){
	for(Iterator<Bighorn> it=harvestedPopulation.iterator();it.hasNext();){
	    Bighorn ram = it.next();
	    if(ram.getAge() >= 8)
		System.out.println(ram+"\t aged = "+(ram.getAge())+",\t becameLegalAged= "+(ram.getAgeAtLegality()));
	}
    }
}



