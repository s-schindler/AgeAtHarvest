/*
 * Author: Susanne Schindler
 * Date: 25.10.2013
 * Email: Susanne.Schindler2@web.de
 * Copyright: Susanne Schindler
 */

import java.text.DecimalFormat;
import java.util.Random;

/**
 * 
 */
public class Bighorn {
    private int age;
    private double hornLength;
    private double baseCircumference;
    private Boolean isLegal;
    private int ageAtLegality;

    private static double[] ageSpecificSurvival;
    private static double meanInitialHornLength;
    private static double SDInitialHornLength;
    private static double meanInitialBaseCircumference;
    private static double SDInitialBaseCircumference;
    private static double[] meanAgeSpecificAnnuliIncrement;
    private static double[] SDAgeSpecificAnnuliIncrement;
    private static double[] meanAgeSpecificBaseIncrement;
    private static double[] SDAgeSpecificBaseIncrement;
    private static double[] legality_length;
    private static double[] legality_base;

    private static final int minAge = 4;
    private static final int maxAge = 16;
    private static final int numberOfAges = maxAge - minAge;

    private static Random randomGenerator;

    /**
     * constructor
     * 
     */
    public Bighorn () {
	setDefaults();
	double rand = randomGenerator.nextGaussian();
	hornLength = getInitialHornLength(rand);
	baseCircumference = getInitialBaseCircumference(rand);
    }

    private void setDefaults(){
	age = minAge;
	isLegal = Boolean.FALSE;
	ageAtLegality =-1;
    }

    private double getInitialHornLength(double rand){
	return Math.max(0,rand*SDInitialHornLength+meanInitialHornLength);
    }

    private double getInitialBaseCircumference(double rand){
	return Math.max(0,rand*SDInitialBaseCircumference+meanInitialBaseCircumference);
    }

    static void initateRandomGenerator(long seed){
	randomGenerator = new Random(seed);
    }

    static void setSurvivalRates(double[] array){
	ageSpecificSurvival = new double[numberOfAges];
	try{
	    for (int a = 0; a<numberOfAges; a++)
		ageSpecificSurvival[a] = array[a];
	}catch(Exception e){
	    System.out.println("Bighorn:setSurvivalRates:Array dimension error. "+e.getMessage());
	}
    }

    static void setInitialHornLength(double[] array){
	try{
	    meanInitialHornLength = array[0];
	    SDInitialHornLength = array[1];
	}catch(Exception e){
	    System.out.println("Bighorn:setInitialHornLength:Array dimension error. "+e.getMessage());
	}
    }

    static void setInitialBaseCircumference(double[] array){
	try{
	    meanInitialBaseCircumference = array[0];
	    SDInitialBaseCircumference = array[1];
	}catch(Exception e){
	    System.out.println("Bighorn:setInitialHornLength:Array dimension error. "+e.getMessage());
	}
    }

    static void setGrowthParams_horn(double[] arrayMeans,double[] arraySDs){
	meanAgeSpecificAnnuliIncrement = new double[numberOfAges];
	SDAgeSpecificAnnuliIncrement = new double[numberOfAges];
	try{
	    for (int a = 0; a<numberOfAges; a++){
		meanAgeSpecificAnnuliIncrement[a] = arrayMeans[a];
		SDAgeSpecificAnnuliIncrement[a] = arraySDs[a];
	    }
	}catch(Exception e){
	    System.out.println("Bighorn:setGrowthParams_horn:Array dimension error. "+e.getMessage());
	}

    }

    static void setGrowthParams_base(double[] arrayMeans,double[] arraySDs){
	meanAgeSpecificBaseIncrement = new double[numberOfAges];
	SDAgeSpecificBaseIncrement = new double[numberOfAges];
	try{
	    for (int a = 0; a<numberOfAges; a++){
		meanAgeSpecificBaseIncrement[a] = arrayMeans[a];
		SDAgeSpecificBaseIncrement[a] = arraySDs[a];
	    }
	}catch(Exception e){
	    System.out.println("Bighorn:setGrowthParams_base:Array dimension error. "+e.getMessage());
	}

    }

    static void setLegalityParams(double[] paramsL,double[] paramsB){
	legality_length = new double[2];
	legality_base = new double[2];
	try{
	    for (int a = 0; a<2; a++){
		legality_length[a] = paramsL[a];
		legality_base[a] = paramsB[a];
	    }
	}catch(Exception e){
	    System.out.println("Bighorn:setLegalityParams:Array dimension error. "+e.getMessage());
	}
    }

    public Boolean updateLegality(){
	if(!isLegal){
	    if(randomGenerator.nextDouble() <= getProbOfBeingLegal_length(hornLength)){
		isLegal = Boolean.TRUE;
		ageAtLegality = age;
	    }
	    else
		isLegal = Boolean.FALSE;
	}
	return isLegal;
    }

 
    public Boolean getIsLegal(){
	return this.isLegal;
    }

    static int getNumberOfAges(){
	return numberOfAges;
    }

    static int getMinAge(){
	return minAge;
    }

    static int getMaxAge(){
	return maxAge;
    }

    public int getAge(){
	return this.age;
    }

    public int getAgeAtLegality(){
	return this.ageAtLegality;
    }

    public double getHornLength(){
	return this.hornLength;
    }

    public double getBaseCircumference(){
	return this.baseCircumference;
    }

    static double getSurvivalAtAge(int a){
	return ageSpecificSurvival[a-minAge];
    }

    static double getLegalityInterceptLength(){
	return legality_length[0];
    }

    static double getLegalitySlopeLength(){
	return legality_length[1];
    }

   static double getLegalityInterceptBase(){
	return legality_base[0];
    }

    static double getLegalitySlopeBase(){
	return legality_base[1];
    }

    static double getProbOfBeingLegal_length(double length){
	return 1/(1+Math.exp(-(legality_length[0]+(length-10)*legality_length[1])));
    }

    static double getProbOfBeingLegal_base(double circumference){
	return 1/(1+Math.exp(-(legality_base[0]+circumference*legality_base[1])));
    }

    static void updateLegality(double ramsHornLength){
	/*get probability of being legal and draw random number*/
    }

    public void growHorn(){
	double rand = randomGenerator.nextGaussian();
	hornLength = hornLength + getAnnulusIncrement(age,rand);
	baseCircumference = baseCircumference + getBaseIncrement(age,rand);
    }

    private static double getAnnulusIncrement(int age,double rand){
	return  rand*SDAgeSpecificAnnuliIncrement[age-minAge]+meanAgeSpecificAnnuliIncrement[age-minAge];
    }

    private static double getBaseIncrement(int age,double rand){
	return  Math.max(0,rand*SDAgeSpecificBaseIncrement[age-minAge]+meanAgeSpecificBaseIncrement[age-minAge]);
    }

    public void ageing(){
	age++;
    }

    static void printSurvivalFct(){
	DecimalFormat df = new DecimalFormat();
	df.setMaximumFractionDigits(4);	
	System.out.println("Age-specific survival function of rams\nAge\tProb to survive to the next year");
	for(int a=0; a<numberOfAges; a++)
	    System.out.println((a+minAge)+"\t"+df.format(ageSpecificSurvival[a]));
    }

    static void printHornStats(){
	DecimalFormat df = new DecimalFormat();
	df.setMaximumFractionDigits(4);	
	System.out.println("Horn length distribution of 4-year old rams\nMean = "+df.format(meanInitialHornLength)+"\tSD = "+df.format(SDInitialHornLength));
	System.out.println("Horn base circumference distribution of 4-year old rams\nMean = "+df.format(meanInitialBaseCircumference)+"\tSD = "+df.format(SDInitialBaseCircumference));
	System.out.println("Age-specific annuli statistics of rams\nAge\tMean\tSD");
	for(int a=0; a<numberOfAges; a++)
	    System.out.println((a+minAge)+"\t"+df.format(meanAgeSpecificAnnuliIncrement[a])+"\t"+df.format(SDAgeSpecificAnnuliIncrement[a]));
	System.out.println("Age-specific horn base statistics of rams\nAge\tMean\tSD");
	for(int a=0; a<numberOfAges; a++)
	    System.out.println((a+minAge)+"\t"+df.format(meanAgeSpecificBaseIncrement[a])+"\t"+df.format(SDAgeSpecificBaseIncrement[a]));

    }

    static void printLegalityParams(){
	DecimalFormat df = new DecimalFormat();
	df.setMaximumFractionDigits(4);	
	System.out.println("Parameters for the probability of being legal as a function of horn length\nIntercept = "+df.format(legality_length[0])+", Slope = "+df.format(legality_length[1]));
	System.out.println("Parameters for the probability of being legal as a function of base circumference\nIntercept = "+df.format(legality_base[0])+", Slope = "+df.format(legality_base[1]));
    }
}



